// packages/components/src/Stack/Stack.stories.tsx
import type { Meta, StoryObj } from '@storybook/react';
import * as Primitives from '@cdk/primitives';

const meta: Meta = {
  title: 'Primitives/Stack',
  parameters: { layout: 'centered' }
};
export default meta;

type Story = StoryObj;

export const Basic: Story = {
  render: () => (
    <Primitives.Stack as="div" style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      <Primitives.Text>Item 1</Primitives.Text>
      <Primitives.Text>Item 2</Primitives.Text>
      <Primitives.Text>Item 3</Primitives.Text>
    </Primitives.Stack>
  )
};
