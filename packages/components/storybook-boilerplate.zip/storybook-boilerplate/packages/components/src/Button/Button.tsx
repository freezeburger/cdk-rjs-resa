// packages/components/src/Button/Button.tsx
import React from 'react';

export type ButtonVariant = 'primary' | 'secondary';
export type ButtonSize = 'sm' | 'md' | 'lg';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
}

export const Button: React.FC<ButtonProps> = ({
  variant = 'primary',
  size = 'md',
  children,
  ...rest
}) => {
  const padding = size === 'sm' ? '6px 10px' : size === 'lg' ? '12px 18px' : '8px 14px';
  const styles: React.CSSProperties = {
    padding,
    borderRadius: 8,
    border: '1px solid rgba(0,0,0,0.1)',
    background: variant === 'primary' ? 'var(--color-primary, #3b82f6)' : 'var(--color-surface, #ffffff)',
    color: variant === 'primary' ? '#fff' : 'var(--color-foreground, #111)',
    cursor: 'pointer'
  };
  return (
    <button style={styles} {...rest}>
      {children}
    </button>
  );
};
