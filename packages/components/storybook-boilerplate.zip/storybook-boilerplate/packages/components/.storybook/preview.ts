// packages/components/.storybook/preview.ts
import type { Preview } from '@storybook/react';
import React from 'react';
import { CoreThemeProvider } from '@cdk/theme'; // <-- adaptez selon votre thème réel

const preview: Preview = {
  decorators: [
    (Story) => (
      <CoreThemeProvider>
        <Story />
      </CoreThemeProvider>
    ),
  ],
  parameters: {
    actions: { argTypesRegex: '^on[A-Z].*' },
    controls: {
      expanded: true,
      matchers: { color: /(background|color)$/i, date: /Date$/i }
    },
    a11y: { disable: false }
  }
};

export default preview;
