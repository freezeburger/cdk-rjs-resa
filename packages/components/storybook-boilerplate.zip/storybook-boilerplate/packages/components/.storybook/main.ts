// packages/components/.storybook/main.ts
import type { StorybookConfig } from '@storybook/react-vite';
import { mergeConfig } from 'vite';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const alias = {
  '@cdk/primitives': path.resolve(__dirname, '../../primitives/src'),
  '@cdk/theme': path.resolve(__dirname, '../../theme/src'),
  '@cdk/icons': path.resolve(__dirname, '../../icons/src'),
};

const config: StorybookConfig = {
  framework: { name: '@storybook/react-vite', options: {} },
  stories: ['../src/**/*.mdx', '../src/**/*.stories.@(ts|tsx)'],
  addons: ['@storybook/addon-essentials', '@storybook/addon-a11y', '@storybook/addon-interactions'],
  docs: { autodocs: 'tag' },
  viteFinal: async (config) => mergeConfig(config, { resolve: { alias } })
};

export default config;
