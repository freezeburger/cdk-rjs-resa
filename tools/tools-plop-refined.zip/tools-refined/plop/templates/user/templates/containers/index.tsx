import TemplateName from "./TemplateName.lazy";
import { withLogic } from "./withLogic.hoc";

export default withLogic(TemplateName);