export interface TemplateNameProps {
   logic?: TemplateNameLogic;
}

export interface TemplateNameLogic {
  // Add your logic here
}