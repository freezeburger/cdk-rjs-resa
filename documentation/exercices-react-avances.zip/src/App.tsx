import React from 'react';
import { DataGrid } from './DataGrid';
import { FormExample } from './FormProvider';

export type Person = { id: number; name: string; age: number; city: string };

function makePeople(count = 20000): Person[] {
  const cities = ['Paris', 'Lyon', 'Marseille', 'Bordeaux', 'Nantes'];
  const rows: Person[] = [];
  for (let i = 0; i < count; i++) {
    rows.push({ id: i + 1, name: `User ${i + 1}`, age: 18 + (i % 60), city: cities[i % cities.length] });
  }
  return rows;
}

export default function App() {
  const rows = React.useMemo(() => makePeople(20000), []);
  return (
    <div style={{ padding: 16, display: 'grid', gap: 24 }}>
      <h2>DataGrid</h2>
      <DataGrid
        rows={rows}
        columns={[
          { key: 'id', header: 'ID', width: 0.5 },
          { key: 'name', header: 'Name', width: 1.5 },
          { key: 'age', header: 'Age', width: 0.5 },
          { key: 'city', header: 'City', width: 1 },
        ]}
        height={360}
        rowHeight={28}
      />

      <h2>FormProvider</h2>
      <FormExample />
    </div>
  );
}
