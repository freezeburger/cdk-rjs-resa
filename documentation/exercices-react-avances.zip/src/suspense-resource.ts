type RecordState<T> =
  | { status: 'pending'; promise: Promise<T>; value?: T; error?: any }
  | { status: 'success'; value: T; promise?: Promise<T>; error?: any }
  | { status: 'error'; error: any; promise?: Promise<T>; value?: T };

const cache = new Map<string, RecordState<any>>();

function load<T>(key: string, fetcher: () => Promise<T>) {
  let record = cache.get(key) as RecordState<T> | undefined;
  if (!record) {
    const promise = fetcher()
      .then((value) => { cache.set(key, { status: 'success', value }); return value; })
      .catch((error) => { cache.set(key, { status: 'error', error }); throw error; });
    record = { status: 'pending', promise };
    cache.set(key, record);
  }
  return record as RecordState<T>;
}

export function prefetch<T>(key: string, fetcher: () => Promise<T>) {
  load(key, fetcher);
}

export function invalidate(key: string) {
  cache.delete(key);
}

export function createResource<T>(key: string, fetcher: () => Promise<T>) {
  return {
    read(): T {
      const record = load<T>(key, fetcher);
      if (record.status === 'pending') throw record.promise;
      if (record.status === 'error') throw record.error;
      return record.value as T;
    },
  };
}
