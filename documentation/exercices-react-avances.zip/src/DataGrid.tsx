import React, { CSSProperties, useMemo, useRef, useState } from 'react';

type Column<T> = { key: keyof T; header: string; width?: number };
type Sort<T> = { key: keyof T; dir: 'asc' | 'desc' } | null;

type DataGridProps<T extends object> = {
  rows: T[];
  columns: Column<T>[];
  height?: number;
  rowHeight?: number;
  overscan?: number;
  initialSort?: Sort<T>;
};

export function DataGrid<T extends object>({
  rows,
  columns,
  height = 400,
  rowHeight = 32,
  overscan = 6,
  initialSort = null,
}: DataGridProps<T>) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [sort, setSort] = useState<Sort<T>>(initialSort);

  const sortedRows = useMemo(() => {
    if (!sort) return rows;
    const { key, dir } = sort;
    const factor = dir === 'asc' ? 1 : -1;
    const clone = rows.slice();
    clone.sort((a: any, b: any) => {
      const va = a[key];
      const vb = b[key];
      if (va === vb) return 0;
      return va > vb ? factor : -factor;
    });
    return clone;
  }, [rows, sort]);

  const [scrollTop, setScrollTop] = useState(0);
  const total = sortedRows.length;
  const totalHeight = total * rowHeight;

  const startIndex = Math.max(0, Math.floor(scrollTop / rowHeight) - overscan);
  const viewportCount = Math.ceil(height / rowHeight) + overscan * 2;
  const endIndex = Math.min(total - 1, startIndex + viewportCount);

  const offsetY = startIndex * rowHeight;
  const visibleRows = sortedRows.slice(startIndex, endIndex + 1);

  const onScroll: React.UIEventHandler<HTMLDivElement> = (e) => {
    setScrollTop(e.currentTarget.scrollTop);
  };

  const headerStyle: CSSProperties = {
    position: 'sticky',
    top: 0,
    background: '#fff',
    zIndex: 1,
    borderBottom: '1px solid #eee',
  };

  function toggleSort(key: keyof T) {
    setSort((prev) => {
      if (!prev || prev.key !== key) return { key, dir: 'asc' };
      if (prev.dir === 'asc') return { key, dir: 'desc' };
      return null;
    });
  }

  return (
    <div
      ref={containerRef}
      onScroll={onScroll}
      style={{
        height,
        overflow: 'auto',
        position: 'relative',
        border: '1px solid #ddd',
        fontFamily: 'system-ui, sans-serif',
        fontSize: 14,
      }}
    >
      <div style={{ height: totalHeight, position: 'relative' }}>
        <div style={{ ...headerStyle, display: 'grid', gridTemplateColumns: columns.map(c => `${c.width ?? 1}fr`).join(' ') }}>
          {columns.map((c) => (
            <div
              key={String(c.key)}
              onClick={() => toggleSort(c.key)}
              style={{ padding: '6px 8px', cursor: 'pointer', fontWeight: 600 }}
            >
              {c.header}
              {sort?.key === c.key ? (sort.dir === 'asc' ? ' ▲' : ' ▼') : ''}
            </div>
          ))}
        </div>

        <div
          style={{
            position: 'absolute',
            top: offsetY + rowHeight,
            left: 0,
            right: 0,
            display: 'grid',
            gridTemplateColumns: columns.map(c => `${c.width ?? 1}fr`).join(' '),
          }}
        >
          {visibleRows.map((row, i) => (
            <React.Fragment key={(row as any).id ?? startIndex + i}>
              {columns.map((c) => (
                <div
                  key={String(c.key)}
                  style={{
                    height: rowHeight,
                    lineHeight: `${rowHeight}px`,
                    padding: '0 8px',
                    borderBottom: '1px solid #f2f2f2',
                    whiteSpace: 'nowrap',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                  }}
                >
                  {String(row[c.key])}
                </div>
              ))}
            </React.Fragment>
          ))}
        </div>
      </div>
    </div>
  );
}
