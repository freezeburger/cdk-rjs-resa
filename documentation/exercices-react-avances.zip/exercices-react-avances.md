# Exercices React avancés — DataGrid, FormProvider, SuspenseResource

Ce document propose **3 exercices** avec **énoncés** et **corrections**.  
Les corrections sont cachées sous des balises `<details>` pour que vous puissiez d’abord tenter les implémentations.

> Stack attendue : **React 18 + TypeScript**. Aucune dépendance externe obligatoire.  
> Organisation suggérée : un fichier par exercice, plus un `App.tsx` pour démontrer.

---

## 1) DataGrid avec windowing, `useRef`, `useMemo` et tri

### 🎯 Objectif
Implémenter un `DataGrid` capable d’afficher **dizaines de milliers de lignes** via **windowing** (rendu d’une fenêtre de lignes visibles), incluant :
- Tri par colonne (asc/desc),
- `useMemo` pour le calcul des lignes triées,
- `useRef` pour référencer le conteneur scrollable,
- Calcul de la fenêtre visible via `scrollTop` et `rowHeight`,
- Option de **row height fixe** (simplification), **sticky header**.

### 🧩 Contraintes
- Props minimales :
  ```ts
  type Column<T> = { key: keyof T; header: string; width?: number; sort?: 'asc' | 'desc' | null };
  type DataGridProps<T> = {
    rows: T[];
    columns: Column<T>[];
    height?: number;        // px, hauteur du viewport scrollable
    rowHeight?: number;     // px, hauteur fixe d’une ligne
    overscan?: number;      // nb de lignes supplémentaires rendues au-dessus/en-dessous
    initialSort?: { key: keyof T; dir: 'asc' | 'desc' };
  };
  ```
- Pas de lib de virtualisation externe.
- Tri stable non obligatoire, mais cohérent.

### 🧪 Données d’exemple
```ts
export type Person = { id: number; name: string; age: number; city: string };

export function makePeople(count = 50000): Person[] {
  const cities = ['Paris', 'Lyon', 'Marseille', 'Bordeaux', 'Nantes'];
  const rows: Person[] = [];
  for (let i = 0; i < count; i++) {
    rows.push({
      id: i + 1,
      name: `User ${i + 1}`,
      age: 18 + (i % 60),
      city: cities[i % cities.length],
    });
  }
  return rows;
}
```

### 🧪 Starter (squelette minimal)
```tsx
import React, { useMemo, useRef, useState } from 'react';

type Column<T> = { key: keyof T; header: string; width?: number };
type Sort<T> = { key: keyof T; dir: 'asc' | 'desc' } | null;

type DataGridProps<T extends object> = {
  rows: T[];
  columns: Column<T>[];
  height?: number;
  rowHeight?: number;
  overscan?: number;
  initialSort?: Sort<T>;
};

export function DataGrid<T extends object>({
  rows,
  columns,
  height = 400,
  rowHeight = 32,
  overscan = 6,
  initialSort = null,
}: DataGridProps<T>) {
  // À faire : useRef pour container, state sort, useMemo pour rows triées,
  // gestion onScroll pour calculer fenêtre, rendu de la zone espacée + lignes visibles seulement.
  return <div>TODO</div>;
}
```

---

<details>
<summary><strong>💡 Correction (cliquez pour dérouler)</strong></summary>

```tsx
import React, { CSSProperties, useMemo, useRef, useState } from 'react';

type Column<T> = { key: keyof T; header: string; width?: number };
type Sort<T> = { key: keyof T; dir: 'asc' | 'desc' } | null;

type DataGridProps<T extends object> = {
  rows: T[];
  columns: Column<T>[];
  height?: number;
  rowHeight?: number;
  overscan?: number;
  initialSort?: Sort<T>;
};

export function DataGrid<T extends object>({
  rows,
  columns,
  height = 400,
  rowHeight = 32,
  overscan = 6,
  initialSort = null,
}: DataGridProps<T>) {
  const containerRef = useRef<HTMLDivElement | null>(null); // ref pour capter scrollTop
  const [sort, setSort] = useState<Sort<T>>(initialSort);   // état local du tri

  // Tri mémoïsé pour éviter recalculs inutiles (rows volumineuses)
  const sortedRows = useMemo(() => {
    if (!sort) return rows;
    const { key, dir } = sort;
    const factor = dir === 'asc' ? 1 : -1;
    // copie pour ne pas muter la prop
    const clone = rows.slice();
    clone.sort((a: any, b: any) => {
      const va = a[key];
      const vb = b[key];
      if (va === vb) return 0;
      return va > vb ? factor : -factor;
    });
    return clone;
  }, [rows, sort]);

  // Calcul de la fenêtre visible
  const [scrollTop, setScrollTop] = useState(0);
  const total = sortedRows.length;
  const totalHeight = total * rowHeight;

  const startIndex = Math.max(0, Math.floor(scrollTop / rowHeight) - overscan);
  const viewportCount = Math.ceil(height / rowHeight) + overscan * 2;
  const endIndex = Math.min(total - 1, startIndex + viewportCount);

  const offsetY = startIndex * rowHeight;
  const visibleRows = sortedRows.slice(startIndex, endIndex + 1);

  const onScroll: React.UIEventHandler<HTMLDivElement> = (e) => {
    setScrollTop(e.currentTarget.scrollTop);
  };

  const headerStyle: CSSProperties = {
    position: 'sticky',
    top: 0,
    background: '#fff',
    zIndex: 1,
    borderBottom: '1px solid #eee',
  };

  function toggleSort(key: keyof T) {
    setSort((prev) => {
      if (!prev || prev.key !== key) return { key, dir: 'asc' };
      if (prev.dir === 'asc') return { key, dir: 'desc' };
      return null; // asc -> desc -> none
    });
  }

  return (
    <div
      ref={containerRef}
      onScroll={onScroll}
      style={{
        height,
        overflow: 'auto',
        position: 'relative',
        border: '1px solid #ddd',
        fontFamily: 'system-ui, sans-serif',
        fontSize: 14,
      }}
    >
      {/* Espace total pour activer la scrollbar */}
      <div style={{ height: totalHeight, position: 'relative' }}>
        {/* En-tête sticky */}
        <div style={{ ...headerStyle, display: 'grid', gridTemplateColumns: columns.map(c => `${c.width ?? 1}fr`).join(' ') }}>
          {columns.map((c) => (
            <div
              key={String(c.key)}
              onClick={() => toggleSort(c.key)}
              style={{ padding: '6px 8px', cursor: 'pointer', fontWeight: 600 }}
              title="Cliquer pour trier"
            >
              {c.header}
              {sort?.key === c.key ? (sort.dir === 'asc' ? ' ▲' : ' ▼') : ''}
            </div>
          ))}
        </div>

        {/* Fenêtre rendue */}
        <div
          style={{
            position: 'absolute',
            top: offsetY + rowHeight, // +rowHeight pour ne pas chevaucher l’en-tête sticky
            left: 0,
            right: 0,
            display: 'grid',
            gridTemplateColumns: columns.map(c => `${c.width ?? 1}fr`).join(' '),
          }}
        >
          {visibleRows.map((row, i) => (
            <React.Fragment key={(row as any).id ?? startIndex + i}>
              {columns.map((c) => (
                <div
                  key={String(c.key)}
                  style={{
                    height: rowHeight,
                    lineHeight: `${rowHeight}px`,
                    padding: '0 8px',
                    borderBottom: '1px solid #f2f2f2',
                    whiteSpace: 'nowrap',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                  }}
                >
                  {String(row[c.key])}
                </div>
              ))}
            </React.Fragment>
          ))}
        </div>
      </div>
    </div>
  );
}
```

</details>

---

## 2) `FormProvider` + `useReducer` + Input custom à validation **asynchrone**

### 🎯 Objectif
Créer un **contexte de formulaire** qui :
- Centralise l’état avec `useReducer`,
- Expose des actions `change`, `blur`, `validateField`,
- Gère des **validations asynchrones** (ex: disponibilité d’un nom d’utilisateur),
- Fournit un **Input custom** (contrôlé) qui affiche les états : `idle | validating | valid | error`,
- Permet une validation globale `validateForm()`.

### 🧩 Contraintes
- État minimal par champ : `{ value, status, error }` où `status` ∈ `idle | validating | valid | error`.
- Mock d’une API async : `checkUsername(value: string): Promise<boolean>`
  - retourne `false` pour des valeurs “réservées” (`admin`, `root`, `test`), `true` sinon, avec un `setTimeout`.

### 🧪 Starter
```tsx
import React, { createContext, useContext, useReducer } from 'react';

type FieldState = {
  value: string;
  status: 'idle' | 'validating' | 'valid' | 'error';
  error?: string;
};
type FormState = Record<string, FieldState>;

type Action =
  | { type: 'CHANGE'; name: string; value: string }
  | { type: 'VALIDATING'; name: string }
  | { type: 'VALID'; name: string }
  | { type: 'ERROR'; name: string; message: string };

const FormCtx = createContext<any>(null);

export function FormProvider({ children }: { children: React.ReactNode }) {
  // TODO: reducer + value du provider
  return <FormCtx.Provider value={null}>{children}</FormCtx.Provider>;
}

export function useForm() {
  const ctx = useContext(FormCtx);
  if (!ctx) throw new Error('useForm must be used within FormProvider');
  return ctx;
}

// TODO: Input custom + validation async
```

---

<details>
<summary><strong>💡 Correction (cliquez pour dérouler)</strong></summary>

```tsx
import React, { createContext, useContext, useReducer } from 'react';

type FieldState = {
  value: string;
  status: 'idle' | 'validating' | 'valid' | 'error';
  error?: string;
};
type FormState = Record<string, FieldState>;

type Action =
  | { type: 'CHANGE'; name: string; value: string }
  | { type: 'VALIDATING'; name: string }
  | { type: 'VALID'; name: string }
  | { type: 'ERROR'; name: string; message: string };

function reducer(state: FormState, action: Action): FormState {
  switch (action.type) {
    case 'CHANGE':
      return {
        ...state,
        [action.name]: { value: action.value, status: 'idle', error: undefined },
      };
    case 'VALIDATING':
      return {
        ...state,
        [action.name]: { ...state[action.name], status: 'validating', error: undefined },
      };
    case 'VALID':
      return {
        ...state,
        [action.name]: { ...state[action.name], status: 'valid', error: undefined },
      };
    case 'ERROR':
      return {
        ...state,
        [action.name]: { ...state[action.name], status: 'error', error: action.message },
      };
    default:
      return state;
  }
}

const FormCtx = createContext<{
  state: FormState;
  change: (name: string, value: string) => void;
  validateField: (name: string, validator: (v: string) => Promise<void>) => Promise<void>;
} | null>(null);

// Mock API async
const reserved = new Set(['admin', 'root', 'test']);
async function checkUsername(value: string): Promise<boolean> {
  await new Promise((r) => setTimeout(r, 500)); // latence simulée
  return !reserved.has(value.toLowerCase());
}

export function FormProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(reducer, {
    username: { value: '', status: 'idle' },
    email: { value: '', status: 'idle' },
  });

  function change(name: string, value: string) {
    dispatch({ type: 'CHANGE', name, value });
  }

  async function validateField(name: string, validator: (v: string) => Promise<void>) {
    dispatch({ type: 'VALIDATING', name });
    try {
      const value = state[name]?.value ?? '';
      await validator(value);
      dispatch({ type: 'VALID', name });
    } catch (e: any) {
      dispatch({ type: 'ERROR', name, message: e.message ?? 'Erreur' });
    }
  }

  return (
    <FormCtx.Provider value={{ state, change, validateField }}>
      {children}
    </FormCtx.Provider>
  );
}

export function useForm() {
  const ctx = useContext(FormCtx);
  if (!ctx) throw new Error('useForm must be used within FormProvider');
  return ctx;
}

type InputProps = {
  name: string;
  label: string;
  placeholder?: string;
  asyncValidator?: (value: string) => Promise<void>;
};

export function Input({ name, label, placeholder, asyncValidator }: InputProps) {
  const { state, change, validateField } = useForm();
  const field = state[name] ?? { value: '', status: 'idle' as const };

  return (
    <div style={{ marginBottom: 12, fontFamily: 'system-ui, sans-serif' }}>
      <label style={{ display: 'block', marginBottom: 4 }}>
        {label}
      </label>
      <input
        value={field.value}
        placeholder={placeholder}
        onChange={(e) => change(name, e.target.value)}
        onBlur={() => {
          if (!asyncValidator) return;
          validateField(name, asyncValidator);
        }}
        style={{ padding: '6px 8px', border: '1px solid #ccc', borderRadius: 4, width: '100%' }}
      />
      <small style={{ display: 'block', marginTop: 4, minHeight: 18 }}>
        {field.status === 'validating' && 'Validation en cours...'}
        {field.status === 'valid' && '✅ Valide'}
        {field.status === 'error' && `❌ ${field.error}`}
      </small>
    </div>
  );
}

// Exemple d’usage
export function FormExample() {
  return (
    <FormProvider>
      <Input
        name="username"
        label="Nom d’utilisateur"
        placeholder="ex: renaud"
        asyncValidator={async (v) => {
          if (v.length < 3) throw new Error('Au moins 3 caractères');
          const ok = await checkUsername(v);
          if (!ok) throw new Error('Nom d’utilisateur indisponible');
        }}
      />
      <Input
        name="email"
        label="Email"
        placeholder="ex: user@example.com"
        asyncValidator={async (v) => {
          if (!/^[\w.-]+@[\w.-]+\.\w+$/.test(v)) throw new Error('Email invalide');
        }}
      />
    </FormProvider>
  );
}
```

</details>

---

## 3) `SuspenseResource` avec cache basé sur `Map` (data fetching léger)

### 🎯 Objectif
Créer un utilitaire **`createResource`** compatible **React Suspense** :
- API : `const resource = createResource(key, fetcher)`
- `resource.read()` :
  - retourne la **donnée** si disponible,
  - **lance** une **Promise** si en cours de chargement (pour Suspense),
  - **lance** l’**erreur** si rejetée (pour ErrorBoundary).
- Utiliser un **cache global `Map`** : `Map<string, { status, value, promise }>`
- Fournir un `prefetch(key, fetcher)` et `invalidate(key)`.

### 🧩 Contraintes
- Pas de lib externe,
- Démo avec un fetch simulé (ou `fetch` réel),
- Exemple d’intégration avec `<Suspense fallback={...}>`.

### 🧪 Starter
```ts
type RecordState<T> =
  | { status: 'pending'; promise: Promise<T>; value?: T; error?: any }
  | { status: 'success'; value: T; promise?: Promise<T>; error?: any }
  | { status: 'error'; error: any; promise?: Promise<T>; value?: T };

const cache = new Map<string, RecordState<any>>();

export function createResource<T>(key: string, fetcher: () => Promise<T>) {
  // TODO: implémenter Map + read() + prefetch/invalidate
  return {
    read(): T {
      throw new Error('TODO');
    },
  };
}
```

---

<details>
<summary><strong>💡 Correction (cliquez pour dérouler)</strong></summary>

```ts
type RecordState<T> =
  | { status: 'pending'; promise: Promise<T>; value?: T; error?: any }
  | { status: 'success'; value: T; promise?: Promise<T>; error?: any }
  | { status: 'error'; error: any; promise?: Promise<T>; value?: T };

const cache = new Map<string, RecordState<any>>();

function load<T>(key: string, fetcher: () => Promise<T>) {
  let record = cache.get(key) as RecordState<T> | undefined;
  if (!record) {
    const promise = fetcher()
      .then((value) => {
        cache.set(key, { status: 'success', value });
        return value;
      })
      .catch((error) => {
        cache.set(key, { status: 'error', error });
        throw error;
      });
    record = { status: 'pending', promise };
    cache.set(key, record);
  }
  return record as RecordState<T>;
}

export function prefetch<T>(key: string, fetcher: () => Promise<T>) {
  load(key, fetcher);
}

export function invalidate(key: string) {
  cache.delete(key);
}

export function createResource<T>(key: string, fetcher: () => Promise<T>) {
  return {
    read(): T {
      const record = load<T>(key, fetcher);
      if (record.status === 'pending') {
        throw record.promise;
      } else if (record.status === 'error') {
        throw record.error;
      } else {
        return record.value as T;
      }
    },
  };
}

// Exemple d’utilisation avec React 18
// ----------------------------------
/*
import React, { Suspense, useState } from 'react';

const fakeApi = (id: number) =>
  new Promise<{ id: number; name: string }>((resolve) =>
    setTimeout(() => resolve({ id, name: 'Item ' + id }), 600)
  );

export function UserCard({ id }: { id: number }) {
  const resource = createResource(`user:${id}`, () => fakeApi(id));
  const data = resource.read();
  return <div>#{data.id} — {data.name}</div>;
}

export function DemoSuspense() {
  const [id, setId] = useState(1);
  return (
    <div style={{ fontFamily: 'system-ui, sans-serif' }}>
      <button onClick={() => setId((x) => x + 1)}>Next</button>
      <button onClick={() => invalidate(`user:${id}`)}>Invalidate</button>
      <Suspense fallback={<div>Chargement…</div>}>
        <UserCard id={id} />
      </Suspense>
    </div>
  );
}
*/
```

</details>

---

## 📎 Annexes

### Mini `App.tsx` de démo (facultatif)
```tsx
import React from 'react';
import { DataGrid } from './DataGrid';
import { FormExample } from './FormProvider';
import { makePeople } from './data';

export default function App() {
  const rows = React.useMemo(() => makePeople(20000), []);
  return (
    <div style={{ padding: 16, display: 'grid', gap: 24 }}>
      <h2>DataGrid</h2>
      <DataGrid
        rows={rows}
        columns={[
          { key: 'id', header: 'ID', width: 0.5 },
          { key: 'name', header: 'Name', width: 1.5 },
          { key: 'age', header: 'Age', width: 0.5 },
          { key: 'city', header: 'City', width: 1 },
        ]}
        height={360}
        rowHeight={28}
      />

      <h2>FormProvider</h2>
      <FormExample />
    </div>
  );
}
```

---

### Conseils pédagogiques (pour atelier avancé)
- **Mesurez** (`performance.now()`, React Profiler) avant/après vos optimisations.
- Vérifiez l’**accessibilité** (navigation clavier, rôles ARIA, focus management).
- Isolez le **state** par composant pour limiter les rerenders (clé : `memo`, `useCallback`).
- Challenge : *rendre la DataGrid contrôlée* (tri/filtre/pagination pilotés par props).

Bonne pratique & bon courage 💪
